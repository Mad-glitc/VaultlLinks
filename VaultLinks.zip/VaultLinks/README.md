# VaultLinks

A premium, offline-first personal knowledge management app for Android. Save any link
(website, Instagram Reel, YouTube video, GitHub repo, Reddit post, PDF, article, anything)
with a custom title, notes, category, tags, and priority — no account, no cloud, no tracking.

## Tech Stack

Kotlin · Jetpack Compose · Material 3 · MVVM + Clean Architecture · Hilt · Room · Paging 3 ·
DataStore · Coroutines/Flow · Navigation Compose · Retrofit/OkHttp + Jsoup (metadata scraping) ·
Coil · WorkManager · Chrome Custom Tabs · kotlinx.serialization

## Getting Started

1. Open the `VaultLinks/` folder in Android Studio (Koala or newer recommended).
2. Let Gradle sync — it will pull all dependencies from Google/Maven Central.
3. Rename `local.properties.example` to `local.properties` and point `sdk.dir` at your
   Android SDK path (Android Studio usually does this automatically on first sync).
4. Run on a device or emulator running **API 26+**.

No API keys, no backend, no account setup required. The app works fully offline except for
a single outbound HTTP GET when you save a new link (to fetch its title/description/preview
image from the page's HTML — see `MetadataFetcher.kt`).

## What's implemented

- Full Room persistence layer (links, categories, collections) with search, filters, sort,
  and Paging 3 for large vaults
- Clean Architecture: domain models/use-cases, repository interfaces + Hilt-bound impls
- OpenGraph/Jsoup-based metadata fetching with YouTube/GitHub enrichment and favicon fallback
- Android Share Intent handling (share from Instagram/YouTube/Chrome/etc. straight into
  VaultLinks)
- Home dashboard (stats, pinned, recent, categories), Save Link, Collections + Collection
  Detail (paged), Search (debounced real-time), Favorites (grid/list), Link Detail
  (open/favorite/read-later/archive/delete/notes/category), Settings (theme, accent,
  PIN + biometric lock, daily reminder, JSON/CSV export & JSON import, privacy policy)
- WorkManager for guaranteed background metadata enrichment and the daily reminder
  notification
- A home-screen widget provider (Quick Save + live saved-count)
- A distinct "Nexus Violet" design system (not default Material You) — see
  `presentation/theme/`

## Known gaps / next steps

This was generated in an extended pass without access to a real Android toolchain, so please
budget time for a first-compile pass in Android Studio. As of the latest revision:

- ✅ **Import Backup** is wired to a real `ActivityResultContracts.OpenDocument()` picker in
  `SettingsScreen.kt` — it copies the picked file into cache, calls
  `BackupManager.importFromJson()`, and shows a success/error dialog either way.
- ✅ **PIN unlock gate screen** exists (`presentation/screen/pinlock/PinUnlockScreen.kt`) with a
  numeric keypad, shake-on-error, and an auto-triggered biometric prompt when that's the user's
  configured method. `Splash` routes to it when `LockManager.isLockEnabled()` is true, before
  the user ever reaches Home.
- ✅ **Encryption at rest** is real: `DatabaseModule.kt` now opens Room on top of SQLCipher
  (`net.zetetic:android-database-sqlcipher`) using a 256-bit passphrase generated once and
  stored via `DatabaseKeyProvider.kt`, which wraps it in `EncryptedSharedPreferences`
  (Android Keystore-backed, AES-256-GCM). The passphrase never touches plaintext storage and
  never leaves the device.
- **Room migrations**: schema is at version 1; any future field changes need a real
  `Migration`, not `fallbackToDestructiveMigration()` (intentionally *not* used, to protect
  user data — but that also means schema changes require you to write the migration).
- **Paging at 100k+ rows**: the DAO/Paging3 plumbing is real and will scale, but it hasn't
  been load-tested against an actual 100k-row database.
- Nested collections (sub-folders) have full DB/repository support but no dedicated
  "create sub-collection" UI yet — `CollectionRepository.observeChildren()` is ready to use.
- No unit/instrumented tests were written given the scope of this pass.
- Still unverified by an actual compiler — see the note at the top of this section.

## Privacy

No accounts, no analytics, no ad SDKs. See `strings.xml` → `privacy_policy_body` and
`SettingsScreen.kt`'s privacy dialog for the exact in-app copy.

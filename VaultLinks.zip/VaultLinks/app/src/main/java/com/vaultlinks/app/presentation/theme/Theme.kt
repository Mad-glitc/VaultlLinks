package com.vaultlinks.app.presentation.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.vaultlinks.app.domain.model.ThemeMode

private val LightColors = lightColorScheme(
    primary = VaultViolet,
    onPrimary = PorcelainSurface,
    primaryContainer = VaultVioletLight,
    onPrimaryContainer = VaultVioletDeep,
    secondary = VaultAmber,
    onSecondary = InkPrimary,
    background = PorcelainBg,
    onBackground = InkPrimary,
    surface = PorcelainSurface,
    onSurface = InkPrimary,
    surfaceVariant = PorcelainSurfaceVariant,
    onSurfaceVariant = InkSecondary,
    outline = HairlineLight,
    error = DangerRed
)

private val DarkColors = darkColorScheme(
    primary = VaultVioletLight,
    onPrimary = VaultVioletDeep,
    primaryContainer = VaultVioletDeep,
    onPrimaryContainer = VaultVioletLight,
    secondary = VaultAmber,
    onSecondary = InkPrimary,
    background = VoidBg,
    onBackground = MoonPrimary,
    surface = VoidSurface,
    onSurface = MoonPrimary,
    surfaceVariant = VoidSurfaceVariant,
    onSurfaceVariant = MoonSecondary,
    outline = HairlineDark,
    error = DangerRed
)

@Composable
fun VaultLinksTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> systemDark
    }

    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (useDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        useDark -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = VaultTypography,
        shapes = VaultShapes,
        content = content
    )
}

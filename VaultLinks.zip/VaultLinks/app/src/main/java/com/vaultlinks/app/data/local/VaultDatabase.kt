package com.vaultlinks.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.vaultlinks.app.data.local.dao.CategoryDao
import com.vaultlinks.app.data.local.dao.CollectionDao
import com.vaultlinks.app.data.local.dao.LinkDao
import com.vaultlinks.app.data.local.entity.CategoryEntity
import com.vaultlinks.app.data.local.entity.CollectionEntity
import com.vaultlinks.app.data.local.entity.LinkEntity

/**
 * The single source of truth for all persisted data. VaultLinks is offline-first: this is
 * the ONLY place app data lives. No remote database, no cloud sync, no external server.
 *
 * The database file itself is protected at the OS layer (app-private storage, only readable
 * by this app's UID) and additionally the "PIN Lock" / biometric gate in [com.vaultlinks.app.security]
 * controls in-app access to the data before the UI is shown.
 */
@Database(
    entities = [LinkEntity::class, CategoryEntity::class, CollectionEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun linkDao(): LinkDao
    abstract fun categoryDao(): CategoryDao
    abstract fun collectionDao(): CollectionDao

    companion object {
        const val DATABASE_NAME = "vaultlinks.db"
    }
}
